import React, { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { ArrowLeft, Pencil } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import StudyForm from "../components/viability/StudyForm";
import PDFReport from "../components/viability/PDFReport";

import ProjectHeader from "../components/viability/ProjectHeader";
import FinancialIndicators from "../components/viability/FinancialIndicators";
import CostBreakdown from "../components/viability/CostBreakdown";
import CashFlowChart from "../components/viability/CashFlowChart";
import BreakEvenChart from "../components/viability/BreakEvenChart";
import SensitivityAnalysis from "../components/viability/SensitivityAnalysis";

export default function ViabilidadeDetalhe() {
  const navigate = useNavigate();
  const [editOpen, setEditOpen] = useState(false);
  const urlParams = new URLSearchParams(window.location.search);
  const studyId = urlParams.get("id");

  const { data: study, isLoading, refetch } = useQuery({
    queryKey: ["viability-study", studyId],
    queryFn: async () => {
      const studies = await base44.entities.ViabilityStudy.filter({ id: studyId });
      return studies[0];
    },
    enabled: !!studyId,
  });

  if (isLoading || !study) {
    return (
      <div className="space-y-6">
        <Skeleton className="h-8 w-48 bg-white/10" />
        <Skeleton className="h-32 w-full bg-white/5 rounded-2xl" />
        <div className="grid grid-cols-6 gap-3">
          {[1, 2, 3, 4, 5, 6].map((i) => (
            <Skeleton key={i} className="h-24 bg-white/5 rounded-xl" />
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6 max-w-7xl">
      <div className="flex items-center justify-between mb-2">
        <Button
          variant="ghost"
          onClick={() => navigate(createPageUrl("Viabilidade"))}
          className="text-white/40 hover:text-white hover:bg-white/5 -ml-2"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Voltar aos estudos
        </Button>
        <div className="flex items-center gap-2">
          <PDFReport study={study} />
          <Button
            variant="outline"
            onClick={() => setEditOpen(true)}
            className="border-white/10 text-white/60 hover:text-white hover:border-white/30 hover:bg-white/5"
          >
            <Pencil className="w-4 h-4 mr-2" /> Editar
          </Button>
        </div>
      </div>

      <Dialog open={editOpen} onOpenChange={setEditOpen}>
        <DialogContent className="bg-[#0D1526] border-white/10 text-white max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-white">Editar Estudo</DialogTitle>
          </DialogHeader>
          <StudyForm study={study} onSave={() => { setEditOpen(false); refetch(); }} onCancel={() => setEditOpen(false)} />
        </DialogContent>
      </Dialog>

      <ProjectHeader study={study} />
      <FinancialIndicators study={study} />
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <CostBreakdown study={study} />
        <CashFlowChart study={study} />
      </div>

      <BreakEvenChart study={study} />
      <SensitivityAnalysis study={study} />
    </div>
  );
}