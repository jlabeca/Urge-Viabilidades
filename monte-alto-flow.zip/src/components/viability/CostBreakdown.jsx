import React from "react";
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip } from "recharts";

const fmt = (v) => `R$ ${(v || 0).toLocaleString("pt-BR", { minimumFractionDigits: 0 })}`;

export default function CostBreakdown({ study }) {
  const data = [
    { name: "Terreno", value: study.custo_terreno_total || 0, color: "#C9A96E" },
    { name: "Engenharia", value: (study.custo_engenharia_unidade || 0) * (study.num_unidades || 0), color: "#4F8ECC" },
    { name: "Impostos", value: study.custo_impostos_total || 0, color: "#E06060" },
    { name: "Comercialização", value: study.custo_comercializacao_total || 0, color: "#6EC97A" },
  ].filter((d) => d.value > 0);

  const total = data.reduce((s, d) => s + d.value, 0);

  return (
    <div className="bg-[#131B2E] rounded-2xl border border-white/5 p-6">
      <h3 className="text-white font-semibold mb-6 text-sm uppercase tracking-wider">Composição de Custos</h3>
      <div className="flex flex-col md:flex-row items-center gap-6">
        <div className="w-44 h-44 flex-shrink-0">
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie data={data} dataKey="value" cx="50%" cy="50%" innerRadius={45} outerRadius={70} strokeWidth={0}>
                {data.map((d, i) => (
                  <Cell key={i} fill={d.color} />
                ))}
              </Pie>
              <Tooltip
                formatter={(v) => fmt(v)}
                contentStyle={{ background: "#1A2340", border: "1px solid rgba(255,255,255,0.1)", borderRadius: "8px", color: "#fff", fontSize: "12px" }}
              />
            </PieChart>
          </ResponsiveContainer>
        </div>
        <div className="flex-1 space-y-3 w-full">
          {data.map((d) => (
            <div key={d.name} className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-2.5 h-2.5 rounded-full" style={{ background: d.color }} />
                <span className="text-white/60 text-sm">{d.name}</span>
              </div>
              <div className="text-right">
                <span className="text-white text-sm font-medium">{fmt(d.value)}</span>
                <span className="text-white/30 text-xs ml-2">({((d.value / total) * 100).toFixed(1)}%)</span>
              </div>
            </div>
          ))}
          <div className="border-t border-white/10 pt-3 flex items-center justify-between">
            <span className="text-white/40 text-sm font-medium">Total</span>
            <span className="text-white font-bold text-sm">{fmt(total)}</span>
          </div>
        </div>
      </div>
    </div>
  );
}