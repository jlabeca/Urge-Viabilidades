import React from "react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, ReferenceLine, Legend, Line, ComposedChart, Area } from "recharts";

const fmt = (v) => `R$ ${(v / 1000).toFixed(0)}k`;

export default function CashFlowChart({ study }) {
  const months = study.prazo_execucao_meses || 10;
  const vgv = study.vgv_total || 0;
  const custoTotal = ((study.custo_terreno_total || 0) +
    (study.custo_engenharia_unidade || 0) * (study.num_unidades || 0) +
    (study.custo_impostos_total || 0) +
    (study.custo_comercializacao_total || 0));

  // Simulate cash flow - cost follows S-curve, revenue follows sales pace
  const data = [];
  let accumulated = 0;
  for (let m = 0; m <= months + 4; m++) {
    // Costs: front-loaded (terrain) then construction
    let costMonth = 0;
    if (m === 0) costMonth = (study.custo_terreno_total || 0);
    else if (m <= months) costMonth = ((custoTotal - (study.custo_terreno_total || 0)) / months);

    // Revenue: starts month 2, ramps up
    let revenueMonth = 0;
    if (m >= 2 && m <= months + 3) {
      const salesMonths = months + 2;
      revenueMonth = vgv / salesMonths;
    }

    const net = revenueMonth - costMonth;
    accumulated += net;

    data.push({
      mes: `M${m}`,
      receita: Math.round(revenueMonth),
      custo: Math.round(-costMonth),
      acumulado: Math.round(accumulated),
    });
  }

  return (
    <div className="bg-[#131B2E] rounded-2xl border border-white/5 p-6">
      <h3 className="text-white font-semibold mb-6 text-sm uppercase tracking-wider">Fluxo de Caixa Projetado</h3>
      <div className="h-72">
        <ResponsiveContainer width="100%" height="100%">
          <ComposedChart data={data} margin={{ top: 5, right: 10, left: 0, bottom: 0 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
            <XAxis dataKey="mes" tick={{ fill: "rgba(255,255,255,0.3)", fontSize: 11 }} axisLine={false} tickLine={false} />
            <YAxis tick={{ fill: "rgba(255,255,255,0.3)", fontSize: 11 }} axisLine={false} tickLine={false} tickFormatter={fmt} />
            <Tooltip
              contentStyle={{ background: "#1A2340", border: "1px solid rgba(255,255,255,0.1)", borderRadius: "8px", color: "#fff", fontSize: "12px" }}
              formatter={(v) => `R$ ${Math.abs(v).toLocaleString("pt-BR")}`}
            />
            <ReferenceLine y={0} stroke="rgba(255,255,255,0.1)" />
            <Bar dataKey="receita" name="Receita" fill="#6EC97A" radius={[3, 3, 0, 0]} opacity={0.8} />
            <Bar dataKey="custo" name="Custo" fill="#E06060" radius={[0, 0, 3, 3]} opacity={0.8} />
            <Line dataKey="acumulado" name="Acumulado" stroke="#C9A96E" strokeWidth={2} dot={false} />
          </ComposedChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}