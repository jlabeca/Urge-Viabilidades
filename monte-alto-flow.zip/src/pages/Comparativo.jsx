import React, { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, RadarChart, Radar, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Legend } from "recharts";
import { Checkbox } from "@/components/ui/checkbox";
import { Building2, ChevronRight, GitCompare, TrendingUp, DollarSign } from "lucide-react";

const fmt = (v) => `R$ ${(v || 0).toLocaleString("pt-BR", { minimumFractionDigits: 0 })}`;
const fmtPerc = (v) => `${((v || 0) * 100).toFixed(1)}%`;

const COLORS = ["#C9A96E", "#4F8ECC", "#6EC97A", "#E06060", "#A78BFA", "#FB923C"];

function calcTIR(study) {
  const months = study.prazo_execucao_meses || 10;
  const vgv = study.vgv_total || 0;
  const custoTotal = (study.custo_terreno_total || 0) +
    (study.custo_engenharia_unidade || 0) * (study.num_unidades || 0) +
    (study.custo_impostos_total || 0) +
    (study.custo_comercializacao_total || 0);
  const flows = [];
  for (let m = 0; m <= months + 4; m++) {
    let c = m === 0 ? (study.custo_terreno_total || 0) : (m <= months ? (custoTotal - (study.custo_terreno_total || 0)) / months : 0);
    let r = m >= 2 && m <= months + 3 ? vgv / (months + 2) : 0;
    flows.push(r - c);
  }
  let rate = 0.01;
  for (let iter = 0; iter < 500; iter++) {
    let npv = 0, dnpv = 0;
    for (let i = 0; i < flows.length; i++) {
      npv += flows[i] / Math.pow(1 + rate, i);
      dnpv -= (i * flows[i]) / Math.pow(1 + rate, i + 1);
    }
    if (Math.abs(npv) < 1 || Math.abs(dnpv) < 0.0001) break;
    rate -= npv / dnpv;
    if (rate <= -1) rate = 0.001;
  }
  return Math.pow(1 + rate, 12) - 1;
}

function normalize(value, min, max) {
  if (max === min) return 50;
  return Math.round(((value - min) / (max - min)) * 100);
}

export default function Comparativo() {
  const navigate = useNavigate();
  const { data: studies, isLoading } = useQuery({
    queryKey: ["viability-studies"],
    queryFn: () => base44.entities.ViabilityStudy.list("-created_date"),
    initialData: [],
  });

  const [selected, setSelected] = useState([]);

  function toggleSelect(id) {
    setSelected((prev) =>
      prev.includes(id) ? prev.filter((x) => x !== id) : prev.length < 5 ? [...prev, id] : prev
    );
  }

  const compared = studies.filter((s) => selected.includes(s.id)).map((s, i) => ({
    ...s,
    color: COLORS[i],
    tir: calcTIR(s),
    custoTotal: (s.custo_terreno_total || 0) + (s.custo_engenharia_unidade || 0) * (s.num_unidades || 0) + (s.custo_impostos_total || 0) + (s.custo_comercializacao_total || 0),
  }));

  // Bar chart data
  const barMetrics = [
    { key: "vgv_total", label: "VGV Total", fmt: (v) => `R$${(v / 1e6).toFixed(2)}M` },
    { key: "resultado_total", label: "Resultado", fmt: (v) => `R$${(v / 1e6).toFixed(2)}M` },
    { key: "custoTotal", label: "Custo Total", fmt: (v) => `R$${(v / 1e6).toFixed(2)}M` },
  ];

  // Radar data
  const radarKeys = ["margem_lucro", "tir", "resultado_total", "num_unidades", "vgv_total"];
  const radarMins = {};
  const radarMaxs = {};
  radarKeys.forEach((k) => {
    const vals = compared.map((s) => s[k] || 0);
    radarMins[k] = Math.min(...vals);
    radarMaxs[k] = Math.max(...vals);
  });
  const radarData = [
    { metric: "Margem (%)", fullMark: 100 },
    { metric: "TIR (%)", fullMark: 100 },
    { metric: "Resultado", fullMark: 100 },
    { metric: "Unidades", fullMark: 100 },
    { metric: "VGV", fullMark: 100 },
  ].map((item, idx) => {
    const k = radarKeys[idx];
    const entry = { ...item };
    compared.forEach((s) => {
      entry[s.nome_empreendimento] = normalize(s[k] || 0, radarMins[k], radarMaxs[k]);
    });
    return entry;
  });

  const metricRows = [
    { label: "VGV Total", key: "vgv_total", format: fmt },
    { label: "Custo Total", key: "custoTotal", format: fmt },
    { label: "Resultado Total", key: "resultado_total", format: fmt },
    { label: "Margem de Lucro", key: "margem_lucro", format: fmtPerc },
    { label: "TIR Anual", key: "tir", format: fmtPerc },
    { label: "Nº Unidades", key: "num_unidades", format: (v) => `${v} un` },
    { label: "Área / Unidade", key: "area_unidade_m2", format: (v) => `${v} m²` },
    { label: "Prazo", key: "prazo_execucao_meses", format: (v) => `${v} meses` },
    { label: "Valor Venda / Un.", key: "valor_venda_unidade", format: fmt },
  ];

  function bestIdx(key, higherIsBetter = true) {
    if (compared.length < 2) return -1;
    const vals = compared.map((s) => s[key] || 0);
    return higherIsBetter ? vals.indexOf(Math.max(...vals)) : vals.indexOf(Math.min(...vals));
  }

  return (
    <div className="space-y-8 max-w-7xl">
      <div>
        <h1 className="text-2xl font-bold text-white">Comparativo de Empreendimentos</h1>
        <p className="text-white/40 text-sm mt-1">Selecione até 5 estudos para comparar</p>
      </div>

      {/* Selection */}
      <div className="bg-[#131B2E] rounded-2xl border border-white/5 p-6">
        <h3 className="text-white font-semibold text-sm uppercase tracking-wider mb-4">Selecionar Estudos</h3>
        {isLoading ? (
          <p className="text-white/30 text-sm">Carregando...</p>
        ) : studies.length === 0 ? (
          <p className="text-white/30 text-sm">Nenhum estudo disponível.</p>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
            {studies.map((s, i) => {
              const isChecked = selected.includes(s.id);
              const colorIdx = selected.indexOf(s.id);
              return (
                <label
                  key={s.id}
                  className={`flex items-center gap-3 p-4 rounded-xl border cursor-pointer transition-all ${
                    isChecked ? "border-[#C9A96E]/40 bg-[#C9A96E]/5" : "border-white/5 hover:border-white/10"
                  }`}
                >
                  <Checkbox
                    checked={isChecked}
                    onCheckedChange={() => toggleSelect(s.id)}
                    className="border-white/20 data-[state=checked]:bg-[#C9A96E] data-[state=checked]:border-[#C9A96E]"
                  />
                  {isChecked && (
                    <div className="w-3 h-3 rounded-full flex-shrink-0" style={{ background: COLORS[colorIdx] }} />
                  )}
                  <div className="min-w-0">
                    <p className="text-white text-sm font-medium truncate">{s.nome_empreendimento}</p>
                    <p className="text-white/30 text-xs">{s.cidade} · {s.num_unidades} un</p>
                  </div>
                </label>
              );
            })}
          </div>
        )}
      </div>

      {compared.length < 2 ? (
        <div className="flex flex-col items-center justify-center py-16 text-center">
          <GitCompare className="w-10 h-10 text-white/20 mb-4" />
          <p className="text-white/40 text-sm">Selecione pelo menos 2 estudos para ver o comparativo.</p>
        </div>
      ) : (
        <>
          {/* Comparison Table */}
          <div className="bg-[#131B2E] rounded-2xl border border-white/5 overflow-hidden">
            <div className="p-6 border-b border-white/5">
              <h3 className="text-white font-semibold text-sm uppercase tracking-wider">Tabela Comparativa</h3>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-white/5">
                    <th className="text-left text-white/40 text-xs uppercase p-4 pl-6">Métrica</th>
                    {compared.map((s) => (
                      <th key={s.id} className="text-right text-xs uppercase p-4">
                        <div className="flex items-center justify-end gap-2">
                          <div className="w-2.5 h-2.5 rounded-full flex-shrink-0" style={{ background: s.color }} />
                          <span className="text-white/70 truncate max-w-[120px]">{s.nome_empreendimento}</span>
                        </div>
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {metricRows.map((row, ri) => {
                    const isBest = (idx) => bestIdx(row.key) === idx;
                    const isWorst = (idx) => bestIdx(row.key, false) === idx && compared.length > 1 && compared[idx][row.key] !== compared[bestIdx(row.key)][row.key];
                    return (
                      <tr key={ri} className="border-b border-white/5 hover:bg-white/[0.02]">
                        <td className="text-white/50 text-sm p-4 pl-6">{row.label}</td>
                        {compared.map((s, si) => (
                          <td key={s.id} className="text-right p-4">
                            <span className={`text-sm font-medium ${isBest(si) ? "text-emerald-400" : isWorst(si) ? "text-red-400" : "text-white"}`}>
                              {row.format(s[row.key] || 0)}
                            </span>
                            {isBest(si) && compared.length > 1 && (
                              <span className="ml-1 text-[10px] text-emerald-400/60">↑</span>
                            )}
                          </td>
                        ))}
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>

          {/* Bar Charts */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {barMetrics.map((metric) => {
              const chartData = compared.map((s) => ({
                name: s.nome_empreendimento.length > 12 ? s.nome_empreendimento.substring(0, 12) + "..." : s.nome_empreendimento,
                value: s[metric.key] || 0,
                fill: s.color,
              }));
              return (
                <div key={metric.key} className="bg-[#131B2E] rounded-2xl border border-white/5 p-5">
                  <h4 className="text-white/60 text-xs uppercase tracking-wider mb-4">{metric.label}</h4>
                  <div className="h-48">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={chartData} margin={{ top: 0, right: 0, left: 0, bottom: 0 }}>
                        <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
                        <XAxis dataKey="name" tick={{ fill: "rgba(255,255,255,0.3)", fontSize: 10 }} axisLine={false} tickLine={false} />
                        <YAxis tick={{ fill: "rgba(255,255,255,0.3)", fontSize: 10 }} axisLine={false} tickLine={false} tickFormatter={(v) => `R$${(v / 1e6).toFixed(1)}M`} />
                        <Tooltip
                          contentStyle={{ background: "#1A2340", border: "1px solid rgba(255,255,255,0.1)", borderRadius: "8px", color: "#fff", fontSize: "12px" }}
                          formatter={(v) => fmt(v)}
                        />
                        <Bar dataKey="value" name={metric.label} radius={[4, 4, 0, 0]}>
                          {chartData.map((d, i) => (
                            <rect key={i} fill={d.fill} />
                          ))}
                        </Bar>
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Radar */}
          {compared.length >= 2 && (
            <div className="bg-[#131B2E] rounded-2xl border border-white/5 p-6">
              <h3 className="text-white font-semibold text-sm uppercase tracking-wider mb-6">Análise Multidimensional (Score Relativo)</h3>
              <div className="h-72">
                <ResponsiveContainer width="100%" height="100%">
                  <RadarChart data={radarData}>
                    <PolarGrid stroke="rgba(255,255,255,0.1)" />
                    <PolarAngleAxis dataKey="metric" tick={{ fill: "rgba(255,255,255,0.5)", fontSize: 11 }} />
                    <PolarRadiusAxis angle={30} domain={[0, 100]} tick={{ fill: "rgba(255,255,255,0.2)", fontSize: 9 }} />
                    {compared.map((s) => (
                      <Radar
                        key={s.id}
                        name={s.nome_empreendimento}
                        dataKey={s.nome_empreendimento}
                        stroke={s.color}
                        fill={s.color}
                        fillOpacity={0.15}
                        strokeWidth={2}
                      />
                    ))}
                    <Legend wrapperStyle={{ color: "rgba(255,255,255,0.5)", fontSize: 11 }} />
                    <Tooltip contentStyle={{ background: "#1A2340", border: "1px solid rgba(255,255,255,0.1)", borderRadius: "8px", color: "#fff", fontSize: "12px" }} />
                  </RadarChart>
                </ResponsiveContainer>
              </div>
              <p className="text-white/20 text-xs text-center mt-2">Valores normalizados (0–100) em relação aos estudos selecionados</p>
            </div>
          )}

          {/* Navigate to study */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {compared.map((s) => (
              <div
                key={s.id}
                onClick={() => navigate(createPageUrl("ViabilidadeDetalhe") + `?id=${s.id}`)}
                className="bg-[#131B2E] rounded-xl border border-white/5 p-4 flex items-center justify-between cursor-pointer hover:border-[#C9A96E]/20 transition-all group"
                style={{ borderLeftColor: s.color, borderLeftWidth: 3 }}
              >
                <div>
                  <p className="text-white text-sm font-medium group-hover:text-[#C9A96E] transition-colors">{s.nome_empreendimento}</p>
                  <p className="text-white/30 text-xs mt-0.5">Ver análise completa</p>
                </div>
                <ChevronRight className="w-4 h-4 text-white/20 group-hover:text-[#C9A96E]" />
              </div>
            ))}
          </div>
        </>
      )}
    </div>
  );
}