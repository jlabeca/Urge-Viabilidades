import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Save, X, Loader2, ChevronDown, ChevronUp } from "lucide-react";

const fieldGroups = [
  {
    title: "Identificação",
    fields: [
      { key: "nome_empreendimento", label: "Nome do Empreendimento", type: "text", required: true },
      { key: "cidade", label: "Cidade", type: "text", required: true },
      { key: "tipo", label: "Tipo", type: "select", options: ["Casas", "Apartamentos", "Comercial", "Misto"] },
      { key: "data_base", label: "Data Base", type: "date" },
      { key: "prazo_execucao_meses", label: "Prazo de Execução (meses)", type: "number" },
      { key: "status", label: "Status", type: "select", options: ["rascunho", "em_analise", "aprovado", "reprovado"],
        labels: { rascunho: "Rascunho", em_analise: "Em Análise", aprovado: "Aprovado", reprovado: "Reprovado" } },
    ],
  },
  {
    title: "Unidades e Áreas",
    fields: [
      { key: "num_unidades", label: "Nº de Unidades", type: "number" },
      { key: "area_unidade_m2", label: "Área por Unidade (m²)", type: "number" },
      { key: "area_total_m2", label: "Área Total (m²)", type: "number", computed: true },
    ],
  },
  {
    title: "Receita",
    fields: [
      { key: "valor_venda_unidade", label: "Valor de Venda por Unidade (R$)", type: "currency" },
      { key: "vgv_total", label: "VGV Total (R$)", type: "currency", computed: true },
    ],
  },
  {
    title: "Custo do Terreno",
    fields: [
      { key: "custo_terreno_unidade", label: "Custo do Terreno por Unidade (R$)", type: "currency" },
      { key: "custo_terreno_total", label: "Custo Terreno Total (R$)", type: "currency", computed: true },
    ],
  },
  {
    title: "Impostos e Taxas",
    fields: [
      { key: "perc_ret", label: "RET (%)", type: "percent" },
      { key: "perc_legalizacao", label: "Legalização / Projetos (%)", type: "percent" },
      { key: "perc_itbi", label: "ITBI (%)", type: "percent" },
      { key: "custo_impostos_unidade", label: "Total Impostos por Unidade (R$)", type: "currency", computed: true },
      { key: "custo_impostos_total", label: "Total Impostos Geral (R$)", type: "currency", computed: true },
    ],
  },
  {
    title: "Comercialização",
    fields: [
      { key: "perc_comercializacao", label: "Comercialização (%)", type: "percent" },
      { key: "perc_institucional", label: "Institucional (%)", type: "percent" },
      { key: "custo_comercializacao_unidade", label: "Custo Comercialização por Unidade (R$)", type: "currency", computed: true },
      { key: "custo_comercializacao_total", label: "Custo Comercialização Total (R$)", type: "currency", computed: true },
    ],
  },
  {
    title: "Engenharia",
    fields: [
      { key: "custo_construcao_m2", label: "Custo Construção por m² (R$)", type: "currency" },
      { key: "perc_custo_engenharia", label: "Adicional Engenharia (%)", type: "percent" },
      { key: "custo_engenharia_unidade", label: "Custo Engenharia por Unidade (R$)", type: "currency", computed: true },
      { key: "custo_engenharia_total", label: "Custo Engenharia Total (R$)", type: "currency", computed: true },
    ],
  },
  {
    title: "Resultado",
    fields: [
      { key: "resultado_unidade", label: "Resultado por Unidade (R$)", type: "currency", computed: true },
      { key: "resultado_total", label: "Resultado Total (R$)", type: "currency", computed: true },
      { key: "margem_lucro", label: "Margem de Lucro (%)", type: "percent", computed: true },
      { key: "taxa_desconto_anual", label: "Taxa de Desconto Anual para VPL (%)", type: "percent" },
    ],
  },
];

function autoCompute(d) {
  const data = { ...d };
  const n = data.num_unidades || 0;
  const areaUn = data.area_unidade_m2 || 0;
  const vendaUn = data.valor_venda_unidade || 0;
  const terrenoUn = data.custo_terreno_unidade || 0;
  const constrM2 = data.custo_construcao_m2 || 0;
  const percEng = data.perc_custo_engenharia || 0;
  const percRet = data.perc_ret || 0;
  const percLeg = data.perc_legalizacao || 0;
  const percItbi = data.perc_itbi || 0;
  const percCom = data.perc_comercializacao || 0;
  const percInst = data.perc_institucional || 0;

  data.area_total_m2 = n * areaUn;
  data.vgv_total = n * vendaUn;
  data.custo_terreno_total = n * terrenoUn;

  const impostoUn = vendaUn * percRet + vendaUn * percLeg + vendaUn * percItbi;
  data.custo_impostos_unidade = Math.round(impostoUn);
  data.custo_impostos_total = Math.round(impostoUn * n);

  const comUn = vendaUn * percCom + vendaUn * percInst;
  data.custo_comercializacao_unidade = Math.round(comUn);
  data.custo_comercializacao_total = Math.round(comUn * n);

  const engUn = constrM2 * areaUn * (1 + percEng);
  data.custo_engenharia_unidade = Math.round(engUn);
  data.custo_engenharia_total = Math.round(engUn * n);

  const resUn = vendaUn - terrenoUn - impostoUn - comUn - engUn;
  data.resultado_unidade = Math.round(resUn);
  data.resultado_total = Math.round(resUn * n);
  data.margem_lucro = data.vgv_total > 0 ? data.resultado_total / data.vgv_total : 0;

  return data;
}

function FieldInput({ field, value, onChange }) {
  const baseClass = "bg-white/5 border-white/10 text-white placeholder:text-white/20 focus:border-[#C9A96E]/50 text-sm h-9";

  if (field.type === "select") {
    return (
      <Select value={String(value || "")} onValueChange={onChange}>
        <SelectTrigger className={`${baseClass} w-full`}>
          <SelectValue placeholder="Selecione..." />
        </SelectTrigger>
        <SelectContent className="bg-[#1A2340] border-white/10 text-white">
          {field.options.map((opt) => (
            <SelectItem key={opt} value={opt} className="text-white focus:bg-white/10">
              {field.labels?.[opt] || opt}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
    );
  }

  if (field.type === "percent") {
    return (
      <div className="relative">
        <Input
          type="number"
          step="0.001"
          value={value !== undefined && value !== null ? (value * 100).toFixed(2) : ""}
          onChange={(e) => onChange(parseFloat(e.target.value) / 100 || 0)}
          disabled={field.computed}
          className={`${baseClass} pr-8 ${field.computed ? "opacity-50 cursor-not-allowed" : ""}`}
        />
        <span className="absolute right-3 top-2 text-white/30 text-sm">%</span>
      </div>
    );
  }

  if (field.type === "currency") {
    return (
      <div className="relative">
        <span className="absolute left-3 top-2 text-white/30 text-sm">R$</span>
        <Input
          type="number"
          step="0.01"
          value={value !== undefined && value !== null ? value : ""}
          onChange={(e) => onChange(parseFloat(e.target.value) || 0)}
          disabled={field.computed}
          className={`${baseClass} pl-9 ${field.computed ? "opacity-50 cursor-not-allowed" : ""}`}
        />
      </div>
    );
  }

  return (
    <Input
      type={field.type}
      value={value !== undefined && value !== null ? value : ""}
      onChange={(e) => onChange(field.type === "number" ? parseFloat(e.target.value) || 0 : e.target.value)}
      disabled={field.computed}
      className={`${baseClass} ${field.computed ? "opacity-50 cursor-not-allowed" : ""}`}
    />
  );
}

export default function StudyForm({ study, onSave, onCancel }) {
  const [data, setData] = useState(autoCompute(study || { status: "em_analise", taxa_desconto_anual: 0.12 }));
  const [saving, setSaving] = useState(false);
  const [openGroups, setOpenGroups] = useState(fieldGroups.map((_, i) => i < 3));
  const queryClient = useQueryClient();

  function handleChange(key, value) {
    setData((prev) => autoCompute({ ...prev, [key]: value }));
  }

  function toggleGroup(i) {
    setOpenGroups((prev) => prev.map((v, idx) => (idx === i ? !v : v)));
  }

  async function handleSave() {
    setSaving(true);
    const payload = { ...data };
    delete payload.id;
    delete payload.created_date;
    delete payload.updated_date;
    delete payload.created_by;
    if (study?.id) {
      await base44.entities.ViabilityStudy.update(study.id, payload);
    } else {
      await base44.entities.ViabilityStudy.create(payload);
    }
    queryClient.invalidateQueries({ queryKey: ["viability-studies"] });
    setSaving(false);
    onSave?.();
  }

  return (
    <div className="space-y-4">
      {fieldGroups.map((group, gi) => (
        <div key={gi} className="bg-[#131B2E] rounded-xl border border-white/5 overflow-hidden">
          <button
            className="w-full flex items-center justify-between px-5 py-4 text-left"
            onClick={() => toggleGroup(gi)}
          >
            <span className="text-white font-semibold text-sm">{group.title}</span>
            {openGroups[gi] ? <ChevronUp className="w-4 h-4 text-white/30" /> : <ChevronDown className="w-4 h-4 text-white/30" />}
          </button>
          {openGroups[gi] && (
            <div className="px-5 pb-5 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {group.fields.map((field) => (
                <div key={field.key}>
                  <Label className="text-white/50 text-xs mb-1.5 block">
                    {field.label}
                    {field.required && <span className="text-[#C9A96E] ml-1">*</span>}
                    {field.computed && <span className="text-white/20 ml-1">(auto)</span>}
                  </Label>
                  <FieldInput
                    field={field}
                    value={data[field.key]}
                    onChange={(v) => handleChange(field.key, v)}
                  />
                </div>
              ))}
            </div>
          )}
        </div>
      ))}

      <div className="flex items-center justify-end gap-3 pt-2">
        {onCancel && (
          <Button variant="ghost" onClick={onCancel} className="text-white/40 hover:text-white">
            <X className="w-4 h-4 mr-2" /> Cancelar
          </Button>
        )}
        <Button
          onClick={handleSave}
          disabled={saving || !data.nome_empreendimento || !data.cidade}
          className="bg-[#C9A96E] hover:bg-[#D4B97E] text-[#0B1120] font-semibold"
        >
          {saving ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Save className="w-4 h-4 mr-2" />}
          {study?.id ? "Salvar Alterações" : "Criar Estudo"}
        </Button>
      </div>
    </div>
  );
}