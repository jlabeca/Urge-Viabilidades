import React from "react";

export default function KPICard({ label, value, sublabel, icon: Icon, color = "gold", small = false }) {
  const colorMap = {
    gold: "from-[#C9A96E]/20 to-[#C9A96E]/5 border-[#C9A96E]/20",
    green: "from-emerald-500/20 to-emerald-500/5 border-emerald-500/20",
    blue: "from-blue-500/20 to-blue-500/5 border-blue-500/20",
    red: "from-red-500/20 to-red-500/5 border-red-500/20",
    purple: "from-purple-500/20 to-purple-500/5 border-purple-500/20",
  };

  const iconColorMap = {
    gold: "text-[#C9A96E]",
    green: "text-emerald-400",
    blue: "text-blue-400",
    red: "text-red-400",
    purple: "text-purple-400",
  };

  return (
    <div className={`bg-gradient-to-br ${colorMap[color]} rounded-xl border p-4 md:p-5`}>
      <div className="flex items-start justify-between mb-3">
        <p className="text-white/40 text-xs uppercase tracking-wider">{label}</p>
        {Icon && <Icon className={`w-4 h-4 ${iconColorMap[color]}`} />}
      </div>
      <p className={`text-white font-bold ${small ? "text-lg" : "text-xl md:text-2xl"}`}>{value}</p>
      {sublabel && <p className="text-white/30 text-xs mt-1">{sublabel}</p>}
    </div>
  );
}