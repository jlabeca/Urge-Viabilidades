import React from "react";
import { Badge } from "@/components/ui/badge";
import { Building2, MapPin, Calendar, Ruler, Home } from "lucide-react";

const statusConfig = {
  rascunho: { label: "Rascunho", class: "bg-white/10 text-white/60" },
  em_analise: { label: "Em Análise", class: "bg-yellow-500/20 text-yellow-400" },
  aprovado: { label: "Aprovado", class: "bg-emerald-500/20 text-emerald-400" },
  reprovado: { label: "Reprovado", class: "bg-red-500/20 text-red-400" },
};

export default function ProjectHeader({ study }) {
  const status = statusConfig[study.status] || statusConfig.em_analise;

  return (
    <div className="bg-gradient-to-r from-[#131B2E] to-[#1A2340] rounded-2xl border border-white/5 p-6 md:p-8">
      <div className="flex flex-col md:flex-row md:items-start justify-between gap-4">
        <div>
          <div className="flex items-center gap-3 mb-2">
            <h1 className="text-xl md:text-2xl font-bold text-white">
              {study.nome_empreendimento || "Monte Alto"}
            </h1>
            <Badge className={`${status.class} border-0 text-xs`}>{status.label}</Badge>
          </div>
          <div className="flex flex-wrap items-center gap-4 text-white/40 text-sm">
            <span className="flex items-center gap-1.5">
              <MapPin className="w-3.5 h-3.5" /> {study.cidade}
            </span>
            <span className="flex items-center gap-1.5">
              <Building2 className="w-3.5 h-3.5" /> {study.tipo}
            </span>
            <span className="flex items-center gap-1.5">
              <Calendar className="w-3.5 h-3.5" /> {study.prazo_execucao_meses} meses
            </span>
            <span className="flex items-center gap-1.5">
              <Home className="w-3.5 h-3.5" /> {study.num_unidades} un
            </span>
            <span className="flex items-center gap-1.5">
              <Ruler className="w-3.5 h-3.5" /> {study.area_unidade_m2} m² / un
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}