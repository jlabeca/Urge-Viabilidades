import React from "react";
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { FileBarChart, TrendingUp, Building2, DollarSign, ChevronRight } from "lucide-react";
import KPICard from "../components/viability/KPICard";

const fmt = (v) => `R$ ${(v || 0).toLocaleString("pt-BR", { minimumFractionDigits: 0 })}`;

export default function Dashboard() {
  const navigate = useNavigate();
  const { data: studies, isLoading } = useQuery({
    queryKey: ["viability-studies"],
    queryFn: () => base44.entities.ViabilityStudy.list("-created_date"),
    initialData: [],
  });

  const totalVGV = studies.reduce((s, st) => s + (st.vgv_total || 0), 0);
  const totalLucro = studies.reduce((s, st) => s + (st.resultado_total || 0), 0);
  const avgMargem = studies.length > 0 ? studies.reduce((s, st) => s + (st.margem_lucro || 0), 0) / studies.length : 0;

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-2xl font-bold text-white">Dashboard</h1>
        <p className="text-white/40 text-sm mt-1">Visão geral dos empreendimentos</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <KPICard label="Total Estudos" value={studies.length} icon={FileBarChart} color="gold" />
        <KPICard label="VGV Total" value={fmt(totalVGV)} icon={DollarSign} color="blue" />
        <KPICard label="Lucro Total" value={fmt(totalLucro)} icon={TrendingUp} color="green" />
        <KPICard label="Margem Média" value={`${(avgMargem * 100).toFixed(1)}%`} icon={Building2} color="purple" />
      </div>

      <div>
        <h2 className="text-white font-semibold text-sm uppercase tracking-wider mb-4">Estudos Recentes</h2>
        {studies.length === 0 ? (
          <div className="text-center py-12 text-white/30">
            <FileBarChart className="w-10 h-10 mx-auto mb-3 opacity-50" />
            <p>Nenhum estudo cadastrado ainda.</p>
          </div>
        ) : (
          <div className="space-y-2">
            {studies.slice(0, 5).map((st) => (
              <div
                key={st.id}
                onClick={() => navigate(createPageUrl("ViabilidadeDetalhe") + `?id=${st.id}`)}
                className="bg-[#131B2E] rounded-xl border border-white/5 p-4 flex items-center justify-between cursor-pointer hover:border-[#C9A96E]/20 transition-all group"
              >
                <div className="flex items-center gap-4">
                  <div className="w-10 h-10 rounded-lg bg-[#C9A96E]/10 flex items-center justify-center">
                    <Building2 className="w-5 h-5 text-[#C9A96E]" />
                  </div>
                  <div>
                    <p className="text-white font-medium text-sm group-hover:text-[#C9A96E] transition-colors">{st.nome_empreendimento}</p>
                    <p className="text-white/30 text-xs">{st.cidade} · {st.num_unidades} un</p>
                  </div>
                </div>
                <div className="flex items-center gap-6">
                  <div className="text-right hidden md:block">
                    <p className="text-white/60 text-xs">VGV</p>
                    <p className="text-white text-sm font-medium">{fmt(st.vgv_total)}</p>
                  </div>
                  <div className="text-right hidden md:block">
                    <p className="text-white/60 text-xs">Margem</p>
                    <p className={`text-sm font-medium ${(st.margem_lucro || 0) > 0.15 ? "text-emerald-400" : "text-yellow-400"}`}>
                      {((st.margem_lucro || 0) * 100).toFixed(1)}%
                    </p>
                  </div>
                  <ChevronRight className="w-4 h-4 text-white/20 group-hover:text-[#C9A96E]" />
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}