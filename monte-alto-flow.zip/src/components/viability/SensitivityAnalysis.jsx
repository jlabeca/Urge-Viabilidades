import React, { useState } from "react";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from "recharts";
import { AlertTriangle, TrendingDown, TrendingUp, Minus, Edit2 } from "lucide-react";
import { Input } from "@/components/ui/input";

const fmt = (v) => `R$ ${(v || 0).toLocaleString("pt-BR", { minimumFractionDigits: 0, maximumFractionDigits: 0 })}`;
const fmtPerc = (v) => `${((v || 0) * 100).toFixed(1)}%`;

function calcScenario(study, costVar, revenueVar) {
  const vgv = (study.vgv_total || 0) * (1 + revenueVar);
  const custoBase = (study.custo_terreno_total || 0) +
    (study.custo_engenharia_unidade || 0) * (study.num_unidades || 0) +
    (study.custo_impostos_total || 0) +
    (study.custo_comercializacao_total || 0);
  const custo = custoBase * (1 + costVar);
  const lucro = vgv - custo;
  const margem = vgv > 0 ? lucro / vgv : 0;
  const roi = custo > 0 ? lucro / custo : 0;
  return { vgv, custo, lucro, margem, roi };
}

export default function SensitivityAnalysis({ study }) {
  const [tab, setTab] = useState("cenarios");
  const [editingScenario, setEditingScenario] = useState(null);
  const [scenarios, setScenarios] = useState([
    { id: "pessimista", name: "Pessimista", costVar: 0.15, revenueVar: -0.10, icon: TrendingDown, color: "#E06060" },
    { id: "realista", name: "Realista", costVar: 0, revenueVar: 0, icon: Minus, color: "#C9A96E" },
    { id: "otimista", name: "Otimista", costVar: -0.05, revenueVar: 0.10, icon: TrendingUp, color: "#6EC97A" },
  ]);

  const handleScenarioChange = (id, field, value) => {
    setScenarios(scenarios.map(s => s.id === id ? { ...s, [field]: value } : s));
  };

  const scenarioData = scenarios.map(s => ({
    ...s,
    ...calcScenario(study, s.costVar, s.revenueVar),
  }));

  // Sensitivity: cost variation impact
  const [costRange, setCostRange] = useState([-20, -15, -10, -5, 0, 5, 10, 15, 20]);
  const costSensitivity = costRange.map(pct => {
    const result = calcScenario(study, pct / 100, 0);
    return { variacao: `${pct > 0 ? '+' : ''}${pct}%`, lucro: result.lucro, margem: result.margem, color: result.lucro > 0 ? "#6EC97A" : "#E06060" };
  });

  // Sensitivity: revenue variation impact
  const [revenueRange, setRevenueRange] = useState([-20, -15, -10, -5, 0, 5, 10, 15, 20]);
  const revenueSensitivity = revenueRange.map(pct => {
    const result = calcScenario(study, 0, pct / 100);
    return { variacao: `${pct > 0 ? '+' : ''}${pct}%`, lucro: result.lucro, margem: result.margem, color: result.lucro > 0 ? "#6EC97A" : "#E06060" };
  });

  // Risk matrix
  const risks = [
    { risk: "Aumento custos construção (+15%)", impact: "Alto", prob: "Média", result: fmt(calcScenario(study, 0.15, 0).lucro) },
    { risk: "Queda preço venda (-10%)", impact: "Alto", prob: "Baixa", result: fmt(calcScenario(study, 0, -0.10).lucro) },
    { risk: "Atraso execução (+3 meses)", impact: "Médio", prob: "Média", result: "Impacto financeiro" },
    { risk: "Vacância / baixa absorção", impact: "Alto", prob: "Baixa", result: fmt(calcScenario(study, 0.05, -0.05).lucro) },
  ];

  const impactColors = { Alto: "text-red-400 bg-red-500/10", Médio: "text-yellow-400 bg-yellow-500/10", Baixo: "text-green-400 bg-green-500/10" };
  const probColors = { Alta: "text-red-400 bg-red-500/10", Média: "text-yellow-400 bg-yellow-500/10", Baixa: "text-green-400 bg-green-500/10" };

  return (
    <div className="bg-[#131B2E] rounded-2xl border border-white/5 p-6">
      <div className="flex items-center gap-2 mb-6">
        <AlertTriangle className="w-4 h-4 text-[#C9A96E]" />
        <h3 className="text-white font-semibold text-sm uppercase tracking-wider">Análise de Sensibilidade & Cenários</h3>
      </div>
      
      <Tabs value={tab} onValueChange={setTab}>
        <TabsList className="bg-white/5 border border-white/10 mb-6">
          <TabsTrigger value="cenarios" className="text-xs data-[state=active]:bg-[#C9A96E]/20 data-[state=active]:text-[#C9A96E]">Cenários</TabsTrigger>
          <TabsTrigger value="custo" className="text-xs data-[state=active]:bg-[#C9A96E]/20 data-[state=active]:text-[#C9A96E]">Sensib. Custo</TabsTrigger>
          <TabsTrigger value="receita" className="text-xs data-[state=active]:bg-[#C9A96E]/20 data-[state=active]:text-[#C9A96E]">Sensib. Receita</TabsTrigger>
          <TabsTrigger value="riscos" className="text-xs data-[state=active]:bg-[#C9A96E]/20 data-[state=active]:text-[#C9A96E]">Riscos</TabsTrigger>
        </TabsList>

        <TabsContent value="cenarios">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {scenarios.map((s) => {
              const data = { ...s, ...calcScenario(study, s.costVar, s.revenueVar) };
              const isEditing = editingScenario === s.id;
              return (
                <div key={s.id} className="rounded-xl border border-white/10 p-5" style={{ borderColor: `${s.color}33` }}>
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center gap-2">
                      <s.icon className="w-4 h-4" style={{ color: s.color }} />
                      <h4 className="text-white font-semibold text-sm">{s.name}</h4>
                    </div>
                    <button onClick={() => setEditingScenario(isEditing ? null : s.id)} className="text-white/30 hover:text-white/60 transition-colors p-1">
                      <Edit2 className="w-3 h-3" />
                    </button>
                  </div>
                  <div className="space-y-3">
                    <div className="flex justify-between items-center">
                      <span className="text-white/40 text-xs">Custos</span>
                      {isEditing ? (
                        <input
                          type="number"
                          step="0.01"
                          value={(s.costVar * 100).toFixed(1)}
                          onChange={(e) => handleScenarioChange(s.id, "costVar", parseFloat(e.target.value) / 100)}
                          className="w-16 bg-white/10 border border-white/20 rounded px-2 py-1 text-white text-xs text-right"
                        />
                      ) : (
                        <span className="text-white/80 text-xs">{s.costVar > 0 ? '+' : ''}{(s.costVar * 100).toFixed(0)}%</span>
                      )}
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-white/40 text-xs">Receita</span>
                      {isEditing ? (
                        <input
                          type="number"
                          step="0.01"
                          value={(s.revenueVar * 100).toFixed(1)}
                          onChange={(e) => handleScenarioChange(s.id, "revenueVar", parseFloat(e.target.value) / 100)}
                          className="w-16 bg-white/10 border border-white/20 rounded px-2 py-1 text-white text-xs text-right"
                        />
                      ) : (
                        <span className="text-white/80 text-xs">{s.revenueVar > 0 ? '+' : ''}{(s.revenueVar * 100).toFixed(0)}%</span>
                      )}
                    </div>
                    <div className="border-t border-white/5 pt-3 space-y-2">
                      <div className="flex justify-between">
                        <span className="text-white/40 text-xs">VGV</span>
                        <span className="text-white text-xs font-medium">{fmt(data.vgv)}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-white/40 text-xs">Custo Total</span>
                        <span className="text-white text-xs font-medium">{fmt(data.custo)}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-white/40 text-xs">Lucro</span>
                        <span className="text-xs font-bold" style={{ color: data.lucro > 0 ? "#6EC97A" : "#E06060" }}>{fmt(data.lucro)}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-white/40 text-xs">Margem</span>
                        <span className="text-xs font-bold" style={{ color: data.margem > 0.10 ? "#6EC97A" : "#E06060" }}>{fmtPerc(data.margem)}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-white/40 text-xs">ROI</span>
                        <span className="text-xs font-bold" style={{ color: data.roi > 0 ? "#6EC97A" : "#E06060" }}>{fmtPerc(data.roi)}</span>
                      </div>
                    </div>
                    </div>
                    </div>
              );
            })}
          </div>
        </TabsContent>

        <TabsContent value="custo">
          <div className="space-y-4">
            <div className="flex gap-2 items-center mb-4">
              <span className="text-white/40 text-xs">Intervalo de variação:</span>
              <input type="number" value={costRange[0]} onChange={(e) => setCostRange([parseInt(e.target.value), ...costRange.slice(1)])} className="w-16 bg-white/10 border border-white/20 rounded px-2 py-1 text-white text-xs" placeholder="Min %" />
              <span className="text-white/20">a</span>
              <input type="number" value={costRange[costRange.length - 1]} onChange={(e) => setCostRange([...costRange.slice(0, -1), parseInt(e.target.value)])} className="w-16 bg-white/10 border border-white/20 rounded px-2 py-1 text-white text-xs" placeholder="Max %" />
            </div>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={costSensitivity} margin={{ top: 5, right: 10, left: 0, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
                  <XAxis dataKey="variacao" tick={{ fill: "rgba(255,255,255,0.3)", fontSize: 11 }} axisLine={false} tickLine={false} />
                  <YAxis tick={{ fill: "rgba(255,255,255,0.3)", fontSize: 11 }} axisLine={false} tickLine={false} tickFormatter={(v) => `R$${(v / 1000).toFixed(0)}k`} />
                  <Tooltip contentStyle={{ background: "#1A2340", border: "1px solid rgba(255,255,255,0.1)", borderRadius: "8px", color: "#fff", fontSize: "12px" }} formatter={(v) => fmt(v)} />
                  <Bar dataKey="lucro" name="Lucro" radius={[4, 4, 0, 0]}>
                    {costSensitivity.map((d, i) => <Cell key={i} fill={d.color} opacity={0.8} />)}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
            <p className="text-white/30 text-xs text-center">Impacto da variação de custos no lucro (receita fixa)</p>
          </div>
        </TabsContent>

        <TabsContent value="receita">
          <div className="space-y-4">
            <div className="flex gap-2 items-center mb-4">
              <span className="text-white/40 text-xs">Intervalo de variação:</span>
              <input type="number" value={revenueRange[0]} onChange={(e) => setRevenueRange([parseInt(e.target.value), ...revenueRange.slice(1)])} className="w-16 bg-white/10 border border-white/20 rounded px-2 py-1 text-white text-xs" placeholder="Min %" />
              <span className="text-white/20">a</span>
              <input type="number" value={revenueRange[revenueRange.length - 1]} onChange={(e) => setRevenueRange([...revenueRange.slice(0, -1), parseInt(e.target.value)])} className="w-16 bg-white/10 border border-white/20 rounded px-2 py-1 text-white text-xs" placeholder="Max %" />
            </div>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={revenueSensitivity} margin={{ top: 5, right: 10, left: 0, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
                  <XAxis dataKey="variacao" tick={{ fill: "rgba(255,255,255,0.3)", fontSize: 11 }} axisLine={false} tickLine={false} />
                  <YAxis tick={{ fill: "rgba(255,255,255,0.3)", fontSize: 11 }} axisLine={false} tickLine={false} tickFormatter={(v) => `R$${(v / 1000).toFixed(0)}k`} />
                  <Tooltip contentStyle={{ background: "#1A2340", border: "1px solid rgba(255,255,255,0.1)", borderRadius: "8px", color: "#fff", fontSize: "12px" }} formatter={(v) => fmt(v)} />
                  <Bar dataKey="lucro" name="Lucro" radius={[4, 4, 0, 0]}>
                    {revenueSensitivity.map((d, i) => <Cell key={i} fill={d.color} opacity={0.8} />)}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
            <p className="text-white/30 text-xs text-center">Impacto da variação de receita no lucro (custos fixos)</p>
          </div>
        </TabsContent>

        <TabsContent value="riscos">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-white/10">
                  <th className="text-left text-white/40 text-xs uppercase py-3 px-2">Risco</th>
                  <th className="text-center text-white/40 text-xs uppercase py-3 px-2">Impacto</th>
                  <th className="text-center text-white/40 text-xs uppercase py-3 px-2">Probabilidade</th>
                  <th className="text-right text-white/40 text-xs uppercase py-3 px-2">Resultado</th>
                </tr>
              </thead>
              <tbody>
                {risks.map((r, i) => (
                  <tr key={i} className="border-b border-white/5">
                    <td className="text-white/80 text-sm py-3 px-2">{r.risk}</td>
                    <td className="text-center py-3 px-2">
                      <span className={`text-xs px-2 py-1 rounded-full ${impactColors[r.impact]}`}>{r.impact}</span>
                    </td>
                    <td className="text-center py-3 px-2">
                      <span className={`text-xs px-2 py-1 rounded-full ${probColors[r.prob]}`}>{r.prob}</span>
                    </td>
                    <td className="text-white/80 text-sm py-3 px-2 text-right font-mono">{r.result}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}