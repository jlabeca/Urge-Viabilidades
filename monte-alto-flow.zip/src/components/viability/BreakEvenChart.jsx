import React, { useState } from "react";
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, ReferenceLine, LineChart, Line } from "recharts";
import { Edit2 } from "lucide-react";

const fmt = (v) => `R$ ${(v / 1000).toFixed(0)}k`;
const fmtMeses = (m) => {
  const anos = Math.floor(m / 12);
  const meses = m % 12;
  if (anos > 0 && meses > 0) return `${anos}a ${meses}m`;
  if (anos > 0) return `${anos} ano${anos > 1 ? 's' : ''}`;
  return `${meses} mês${meses > 1 ? 'es' : ''}`;
};

export default function BreakEvenChart({ study }) {
  const units = study.num_unidades || 40;
  const valorVenda = study.valor_venda_unidade || 0;
  const prazo = study.prazo_execucao_meses || 24;
  const custoTotal = (study.custo_terreno_total || 0) +
    (study.custo_engenharia_unidade || 0) * units +
    (study.custo_impostos_total || 0) +
    (study.custo_comercializacao_total || 0);

  const [cronograma, setCronograma] = useState([
    { mes: 1, vendas: 0 },
    { mes: 2, vendas: Math.ceil(units * 0.05) },
    { mes: 3, vendas: Math.ceil(units * 0.10) },
    { mes: 6, vendas: Math.ceil(units * 0.25) },
    { mes: 12, vendas: Math.ceil(units * 0.50) },
    { mes: 18, vendas: Math.ceil(units * 0.80) },
    { mes: prazo, vendas: units },
  ]);
  const [editingMes, setEditingMes] = useState(null);

  const interpolateSales = () => {
    const schedule = [...cronograma].sort((a, b) => a.mes - b.mes);
    const fullSchedule = [];
    for (let m = 0; m <= prazo; m++) {
      let vendas = 0;
      for (let i = 0; i < schedule.length - 1; i++) {
        const cur = schedule[i];
        const next = schedule[i + 1];
        if (m >= cur.mes && m <= next.mes) {
          const progress = (m - cur.mes) / (next.mes - cur.mes);
          vendas = Math.ceil(cur.vendas + (next.vendas - cur.vendas) * progress);
          break;
        }
      }
      if (m >= schedule[schedule.length - 1].mes) {
        vendas = schedule[schedule.length - 1].vendas;
      }
      fullSchedule.push({
        mes: m,
        vendas,
        receita: vendas * valorVenda,
        custoProrata: (custoTotal / prazo) * m,
        resultado: vendas * valorVenda - (custoTotal / prazo) * m,
      });
    }
    return fullSchedule;
  };

  const data = interpolateSales();
  const breakEvenMonth = data.find(d => d.resultado >= 0)?.mes || prazo;

  return (
    <div className="bg-[#131B2E] rounded-2xl border border-white/5 p-6 space-y-6">
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-white font-semibold text-sm uppercase tracking-wider">Ponto de Equilíbrio com Cronograma de Vendas</h3>
          <button onClick={() => setEditingMes(editingMes ? null : 'schedule')} className="text-white/30 hover:text-white/60 transition-colors p-1">
            <Edit2 className="w-3 h-3" />
          </button>
        </div>
        
        {editingMes === 'schedule' && (
          <div className="bg-white/5 rounded-lg p-4 space-y-3">
            <p className="text-white/40 text-xs">Edite o cronograma de vendas mensais:</p>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
              {cronograma.map((item) => (
                <div key={item.mes} className="space-y-1">
                  <label className="text-white/30 text-[10px]">Mês {item.mes}</label>
                  <input
                    type="number"
                    min="0"
                    max={units}
                    value={item.vendas}
                    onChange={(e) => setCronograma(cronograma.map(c => c.mes === item.mes ? { ...c, vendas: parseInt(e.target.value) } : c))}
                    className="w-full bg-white/10 border border-white/20 rounded px-2 py-1 text-white text-xs text-center"
                  />
                </div>
              ))}
            </div>
          </div>
        )}
        
        <span className="text-[#C9A96E] text-xs font-medium">Break-even: mês {breakEvenMonth} ({fmtMeses(breakEvenMonth)})</span>
      </div>

      <div className="h-64">
        <ResponsiveContainer width="100%" height="100%">
          <LineChart data={data} margin={{ top: 5, right: 60, left: 0, bottom: 0 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
            <XAxis dataKey="mes" tick={{ fill: "rgba(255,255,255,0.3)", fontSize: 11 }} axisLine={false} tickLine={false} label={{ value: "Meses", position: "insideBottom", offset: -5, fill: "rgba(255,255,255,0.2)", fontSize: 10 }} />
            <YAxis tick={{ fill: "rgba(255,255,255,0.3)", fontSize: 11 }} axisLine={false} tickLine={false} tickFormatter={fmt} />
            <YAxis yAxisId="right" tick={{ fill: "rgba(255,255,255,0.3)", fontSize: 11 }} axisLine={false} tickLine={false} orientation="right" label={{ value: "Unidades", angle: 90, position: "insideRight", offset: -10, fill: "rgba(255,255,255,0.2)", fontSize: 10 }} />
            <Tooltip contentStyle={{ background: "#1A2340", border: "1px solid rgba(255,255,255,0.1)", borderRadius: "8px", color: "#fff", fontSize: "12px" }} formatter={(v) => typeof v === 'number' && v > 100 ? `R$ ${v.toLocaleString("pt-BR")}` : v} />
            <ReferenceLine y={0} stroke="rgba(255,255,255,0.2)" strokeDasharray="5 5" />
            <ReferenceLine x={breakEvenMonth} stroke="#C9A96E" strokeDasharray="5 5" label={{ value: `BE: mês ${breakEvenMonth}`, position: "top", fill: "#C9A96E", fontSize: 10 }} />
            <Line type="monotone" dataKey="resultado" stroke="#6EC97A" strokeWidth={2} dot={false} name="Resultado Acumulado" />
            <Line type="stepAfter" dataKey="vendas" stroke="#8B6FA0" strokeWidth={2} dot={false} name="Unidades Vendidas" yAxisId="right" />
          </LineChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}