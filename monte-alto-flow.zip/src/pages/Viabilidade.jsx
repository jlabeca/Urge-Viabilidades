import React, { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Plus, FileBarChart, ChevronRight, MapPin, Building2, Pencil, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import StudyForm from "../components/viability/StudyForm";

const fmt = (v) => `R$ ${(v || 0).toLocaleString("pt-BR", { minimumFractionDigits: 0 })}`;
const fmtPerc = (v) => `${((v || 0) * 100).toFixed(1)}%`;

const statusConfig = {
  rascunho: { label: "Rascunho", class: "bg-white/10 text-white/50" },
  em_analise: { label: "Em Análise", class: "bg-yellow-500/20 text-yellow-400" },
  aprovado: { label: "Aprovado", class: "bg-emerald-500/20 text-emerald-400" },
  reprovado: { label: "Reprovado", class: "bg-red-500/20 text-red-400" },
};

export default function Viabilidade() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [formOpen, setFormOpen] = useState(false);
  const [editStudy, setEditStudy] = useState(null);
  const [deleteId, setDeleteId] = useState(null);

  const { data: studies, isLoading } = useQuery({
    queryKey: ["viability-studies"],
    queryFn: () => base44.entities.ViabilityStudy.list("-created_date"),
    initialData: [],
  });

  async function handleDelete() {
    await base44.entities.ViabilityStudy.delete(deleteId);
    queryClient.invalidateQueries({ queryKey: ["viability-studies"] });
    setDeleteId(null);
  }

  return (
    <div className="space-y-8">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-white">Estudos de Viabilidade</h1>
          <p className="text-white/40 text-sm mt-1">Gerencie e analise seus empreendimentos</p>
        </div>
        <Button
          onClick={() => { setEditStudy(null); setFormOpen(true); }}
          className="bg-[#C9A96E] hover:bg-[#D4B97E] text-[#0B1120] font-semibold"
        >
          <Plus className="w-4 h-4 mr-2" /> Novo Estudo
        </Button>
      </div>

      {/* Form Dialog */}
      <Dialog open={formOpen} onOpenChange={setFormOpen}>
        <DialogContent className="bg-[#0D1526] border-white/10 text-white max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-white">{editStudy ? "Editar Estudo" : "Novo Estudo de Viabilidade"}</DialogTitle>
          </DialogHeader>
          <StudyForm study={editStudy} onSave={() => setFormOpen(false)} onCancel={() => setFormOpen(false)} />
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation */}
      <AlertDialog open={!!deleteId} onOpenChange={() => setDeleteId(null)}>
        <AlertDialogContent className="bg-[#0D1526] border-white/10 text-white">
          <AlertDialogHeader>
            <AlertDialogTitle className="text-white">Excluir estudo?</AlertDialogTitle>
            <AlertDialogDescription className="text-white/50">Esta ação não pode ser desfeita.</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel className="bg-white/5 border-white/10 text-white hover:bg-white/10">Cancelar</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete} className="bg-red-600 hover:bg-red-700 text-white">Excluir</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {isLoading ? (
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {[1, 2, 3].map((i) => (
            <div key={i} className="bg-[#131B2E] rounded-2xl border border-white/5 p-6">
              <Skeleton className="h-5 w-40 bg-white/10 mb-3" />
              <Skeleton className="h-4 w-28 bg-white/5 mb-6" />
              <Skeleton className="h-20 w-full bg-white/5" />
            </div>
          ))}
        </div>
      ) : studies.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-20 text-center">
          <div className="w-16 h-16 rounded-2xl bg-[#C9A96E]/10 flex items-center justify-center mb-4">
            <FileBarChart className="w-8 h-8 text-[#C9A96E]" />
          </div>
          <h3 className="text-white font-semibold text-lg mb-2">Nenhum estudo encontrado</h3>
          <p className="text-white/40 text-sm max-w-sm">Crie seu primeiro estudo de viabilidade para começar a analisar empreendimentos.</p>
        </div>
      ) : (
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {studies.map((study) => {
            const status = statusConfig[study.status] || statusConfig.em_analise;
            return (
              <div
                key={study.id}
                className="bg-[#131B2E] rounded-2xl border border-white/5 p-6 hover:border-[#C9A96E]/20 transition-all group"
              >
                <div className="flex items-start justify-between mb-4">
                  <div
                    className="flex-1 cursor-pointer"
                    onClick={() => navigate(createPageUrl("ViabilidadeDetalhe") + `?id=${study.id}`)}
                  >
                    <h3 className="text-white font-semibold group-hover:text-[#C9A96E] transition-colors">
                      {study.nome_empreendimento}
                    </h3>
                    <div className="flex items-center gap-3 mt-1.5 text-white/30 text-xs">
                      <span className="flex items-center gap-1"><MapPin className="w-3 h-3" /> {study.cidade}</span>
                      <span className="flex items-center gap-1"><Building2 className="w-3 h-3" /> {study.tipo}</span>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className={`text-[10px] px-2 py-1 rounded-full ${status.class}`}>{status.label}</span>
                    <button
                      onClick={(e) => { e.stopPropagation(); setEditStudy(study); setFormOpen(true); }}
                      className="text-white/20 hover:text-[#C9A96E] transition-colors p-1"
                    >
                      <Pencil className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={(e) => { e.stopPropagation(); setDeleteId(study.id); }}
                      className="text-white/20 hover:text-red-400 transition-colors p-1"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>

                <div
                  className="cursor-pointer"
                  onClick={() => navigate(createPageUrl("ViabilidadeDetalhe") + `?id=${study.id}`)}
                >
                  <div className="grid grid-cols-2 gap-3 mb-4">
                    <div className="bg-white/5 rounded-lg p-3">
                      <p className="text-white/30 text-[10px] uppercase">VGV</p>
                      <p className="text-white text-sm font-semibold">{fmt(study.vgv_total)}</p>
                    </div>
                    <div className="bg-white/5 rounded-lg p-3">
                      <p className="text-white/30 text-[10px] uppercase">Margem</p>
                      <p className={`text-sm font-semibold ${(study.margem_lucro || 0) > 0.15 ? "text-emerald-400" : "text-yellow-400"}`}>
                        {fmtPerc(study.margem_lucro)}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-white/20 text-xs">{study.num_unidades} un · {study.area_unidade_m2} m²</span>
                    <ChevronRight className="w-4 h-4 text-white/20 group-hover:text-[#C9A96E] transition-colors" />
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}