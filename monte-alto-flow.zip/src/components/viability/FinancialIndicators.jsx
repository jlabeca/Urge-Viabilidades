import React from "react";
import KPICard from "./KPICard";
import { TrendingUp, Percent, DollarSign, Clock, Target, BarChart3 } from "lucide-react";

function calcVPL(cashFlows, taxaMensal) {
  return cashFlows.reduce((sum, cf, i) => sum + cf / Math.pow(1 + taxaMensal, i), 0);
}

function calcTIR(cashFlows, guess = 0.01) {
  let rate = guess;
  for (let iter = 0; iter < 1000; iter++) {
    let npv = 0, dnpv = 0;
    for (let i = 0; i < cashFlows.length; i++) {
      npv += cashFlows[i] / Math.pow(1 + rate, i);
      dnpv -= (i * cashFlows[i]) / Math.pow(1 + rate, i + 1);
    }
    if (Math.abs(npv) < 0.01) break;
    rate -= npv / dnpv;
    if (rate <= -1) rate = 0.001;
  }
  return rate;
}

function buildCashFlows(study) {
  const months = study.prazo_execucao_meses || 10;
  const vgv = study.vgv_total || 0;
  const custoTotal = (study.custo_terreno_total || 0) +
    (study.custo_engenharia_unidade || 0) * (study.num_unidades || 0) +
    (study.custo_impostos_total || 0) +
    (study.custo_comercializacao_total || 0);

  const flows = [];
  for (let m = 0; m <= months + 4; m++) {
    let costMonth = 0;
    if (m === 0) costMonth = (study.custo_terreno_total || 0);
    else if (m <= months) costMonth = (custoTotal - (study.custo_terreno_total || 0)) / months;
    
    let revenueMonth = 0;
    if (m >= 2 && m <= months + 3) {
      revenueMonth = vgv / (months + 2);
    }
    flows.push(revenueMonth - costMonth);
  }
  return flows;
}

const fmt = (v) => `R$ ${(v || 0).toLocaleString("pt-BR", { minimumFractionDigits: 0, maximumFractionDigits: 0 })}`;
const fmtPerc = (v) => `${((v || 0) * 100).toFixed(1)}%`;

export default function FinancialIndicators({ study }) {
  const cashFlows = buildCashFlows(study);
  const taxaAnual = study.taxa_desconto_anual || 0.12;
  const taxaMensal = Math.pow(1 + taxaAnual, 1 / 12) - 1;
  
  const vpl = calcVPL(cashFlows, taxaMensal);
  const tirMensal = calcTIR(cashFlows);
  const tirAnual = Math.pow(1 + tirMensal, 12) - 1;
  
  // Payback
  let accumulated = 0;
  let paybackMonth = null;
  for (let i = 0; i < cashFlows.length; i++) {
    accumulated += cashFlows[i];
    if (accumulated >= 0 && paybackMonth === null) {
      paybackMonth = i;
    }
  }

  // Break-even point
  const vgv = study.vgv_total || 0;
  const custoTotal = (study.custo_terreno_total || 0) +
    (study.custo_engenharia_unidade || 0) * (study.num_unidades || 0) +
    (study.custo_impostos_total || 0) +
    (study.custo_comercializacao_total || 0);
  const valorVendaUn = study.valor_venda_unidade || 0;
  const breakEvenUnits = valorVendaUn > 0 ? Math.ceil(custoTotal / valorVendaUn) : 0;
  const breakEvenPerc = study.num_unidades > 0 ? (breakEvenUnits / study.num_unidades) * 100 : 0;

  const margem = study.margem_lucro || (vgv > 0 ? (study.resultado_total || 0) / vgv : 0);
  const roi = custoTotal > 0 ? (study.resultado_total || 0) / custoTotal : 0;

  return (
    <div className="space-y-6">
      <h3 className="text-white font-semibold text-sm uppercase tracking-wider">Indicadores de Rentabilidade</h3>
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
        <KPICard label="VGV" value={fmt(vgv)} icon={DollarSign} color="gold" small />
        <KPICard label="Margem Lucro" value={fmtPerc(margem)} sublabel={fmt(study.resultado_total)} icon={Percent} color={margem > 0.15 ? "green" : "red"} small />
        <KPICard label="VPL" value={fmt(vpl)} sublabel={`Taxa: ${(taxaAnual * 100).toFixed(0)}% a.a.`} icon={TrendingUp} color={vpl > 0 ? "green" : "red"} small />
        <KPICard label="TIR" value={fmtPerc(tirAnual)} sublabel={`${fmtPerc(tirMensal)} a.m.`} icon={BarChart3} color={tirAnual > taxaAnual ? "green" : "red"} small />
        <KPICard label="Payback" value={paybackMonth !== null ? `${paybackMonth} meses` : "N/A"} icon={Clock} color="blue" small />
        <KPICard label="Ponto Equilíbrio" value={`${breakEvenUnits} un`} sublabel={`${breakEvenPerc.toFixed(0)}% das unidades`} icon={Target} color="purple" small />
      </div>
    </div>
  );
}