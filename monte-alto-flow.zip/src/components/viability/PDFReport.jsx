import React, { useRef, useState } from "react";
import { Button } from "@/components/ui/button";
import { FileDown, Loader2 } from "lucide-react";
import html2canvas from "html2canvas";
import jsPDF from "jspdf";

const fmt = (v) => `R$ ${(v || 0).toLocaleString("pt-BR", { minimumFractionDigits: 0 })}`;
const fmtPerc = (v) => `${((v || 0) * 100).toFixed(2)}%`;

function calcVPL(cashFlows, taxaMensal) {
  return cashFlows.reduce((sum, cf, i) => sum + cf / Math.pow(1 + taxaMensal, i), 0);
}

function calcTIR(cashFlows) {
  let rate = 0.01;
  for (let iter = 0; iter < 1000; iter++) {
    let npv = 0, dnpv = 0;
    for (let i = 0; i < cashFlows.length; i++) {
      npv += cashFlows[i] / Math.pow(1 + rate, i);
      dnpv -= (i * cashFlows[i]) / Math.pow(1 + rate, i + 1);
    }
    if (Math.abs(npv) < 0.01 || Math.abs(dnpv) < 0.0001) break;
    rate -= npv / dnpv;
    if (rate <= -1) rate = 0.001;
  }
  return rate;
}

function buildCashFlows(study) {
  const months = study.prazo_execucao_meses || 10;
  const vgv = study.vgv_total || 0;
  const custoTotal = (study.custo_terreno_total || 0) +
    (study.custo_engenharia_unidade || 0) * (study.num_unidades || 0) +
    (study.custo_impostos_total || 0) +
    (study.custo_comercializacao_total || 0);
  const flows = [];
  for (let m = 0; m <= months + 4; m++) {
    let costMonth = m === 0 ? (study.custo_terreno_total || 0) : (m <= months ? (custoTotal - (study.custo_terreno_total || 0)) / months : 0);
    let revenueMonth = (m >= 2 && m <= months + 3) ? vgv / (months + 2) : 0;
    flows.push(revenueMonth - costMonth);
  }
  return flows;
}

function ReportTemplate({ study, reportRef }) {
  const cashFlows = buildCashFlows(study);
  const taxaAnual = study.taxa_desconto_anual || 0.12;
  const taxaMensal = Math.pow(1 + taxaAnual, 1 / 12) - 1;
  const vpl = calcVPL(cashFlows, taxaMensal);
  const tirMensal = calcTIR(cashFlows);
  const tirAnual = Math.pow(1 + tirMensal, 12) - 1;

  let accumulated = 0, paybackMonth = null;
  for (let i = 0; i < cashFlows.length; i++) {
    accumulated += cashFlows[i];
    if (accumulated >= 0 && paybackMonth === null) paybackMonth = i;
  }

  const custoTotal = (study.custo_terreno_total || 0) +
    (study.custo_engenharia_unidade || 0) * (study.num_unidades || 0) +
    (study.custo_impostos_total || 0) +
    (study.custo_comercializacao_total || 0);
  const breakEvenUnits = study.valor_venda_unidade > 0 ? Math.ceil(custoTotal / study.valor_venda_unidade) : 0;

  const row = (label, value, highlight = false) => (
    <tr style={{ background: highlight ? "#f8f4ee" : "white" }}>
      <td style={{ padding: "6px 12px", color: "#555", fontSize: 12 }}>{label}</td>
      <td style={{ padding: "6px 12px", textAlign: "right", fontWeight: highlight ? 700 : 500, color: highlight ? "#8B6914" : "#222", fontSize: 12 }}>{value}</td>
    </tr>
  );

  return (
    <div ref={reportRef} style={{ fontFamily: "Arial, sans-serif", background: "white", width: 794, padding: 40, boxSizing: "border-box" }}>
      {/* Header */}
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 24, paddingBottom: 16, borderBottom: "2px solid #C9A96E" }}>
        <div>
          <div style={{ fontSize: 22, fontWeight: 700, color: "#1a2340" }}>Estudo de Viabilidade</div>
          <div style={{ fontSize: 14, color: "#888", marginTop: 2 }}>{study.nome_empreendimento} · {study.cidade}</div>
        </div>
        <div style={{ textAlign: "right" }}>
          <div style={{ fontSize: 11, color: "#aaa" }}>Gerado em</div>
          <div style={{ fontSize: 12, color: "#555" }}>{new Date().toLocaleDateString("pt-BR")}</div>
          <div style={{ fontSize: 11, marginTop: 4, background: "#C9A96E", color: "white", padding: "2px 8px", borderRadius: 4 }}>
            {study.status === "aprovado" ? "Aprovado" : study.status === "em_analise" ? "Em Análise" : study.status === "reprovado" ? "Reprovado" : "Rascunho"}
          </div>
        </div>
      </div>

      {/* Project Info */}
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr 1fr", gap: 12, marginBottom: 24 }}>
        {[
          { l: "Tipo", v: study.tipo },
          { l: "Unidades", v: `${study.num_unidades} un` },
          { l: "Área / Unidade", v: `${study.area_unidade_m2} m²` },
          { l: "Prazo", v: `${study.prazo_execucao_meses} meses` },
        ].map((it, i) => (
          <div key={i} style={{ background: "#f5f5f5", borderRadius: 8, padding: 12 }}>
            <div style={{ fontSize: 10, color: "#999", textTransform: "uppercase" }}>{it.l}</div>
            <div style={{ fontSize: 14, fontWeight: 700, color: "#222", marginTop: 2 }}>{it.v || "—"}</div>
          </div>
        ))}
      </div>

      {/* KPIs */}
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 12, marginBottom: 24 }}>
        {[
          { l: "VGV Total", v: fmt(study.vgv_total), color: "#8B6914" },
          { l: "Resultado Total", v: fmt(study.resultado_total), color: study.resultado_total > 0 ? "#1a6b40" : "#b00020" },
          { l: "Margem de Lucro", v: fmtPerc(study.margem_lucro), color: (study.margem_lucro || 0) > 0.15 ? "#1a6b40" : "#b00020" },
          { l: "VPL", v: fmt(vpl), color: vpl > 0 ? "#1a6b40" : "#b00020" },
          { l: "TIR Anual", v: fmtPerc(tirAnual), color: tirAnual > taxaAnual ? "#1a6b40" : "#b00020" },
          { l: "Payback", v: paybackMonth !== null ? `${paybackMonth} meses` : "N/A", color: "#1a2340" },
        ].map((it, i) => (
          <div key={i} style={{ border: "1px solid #eee", borderRadius: 8, padding: 12 }}>
            <div style={{ fontSize: 10, color: "#999", textTransform: "uppercase" }}>{it.l}</div>
            <div style={{ fontSize: 16, fontWeight: 700, color: it.color, marginTop: 4 }}>{it.v}</div>
          </div>
        ))}
      </div>

      {/* Cost Table */}
      <div style={{ marginBottom: 24 }}>
        <div style={{ fontSize: 13, fontWeight: 700, color: "#1a2340", marginBottom: 8, textTransform: "uppercase", letterSpacing: 1 }}>Composição de Custos e Receitas</div>
        <table style={{ width: "100%", borderCollapse: "collapse", border: "1px solid #eee", borderRadius: 8, overflow: "hidden" }}>
          <thead>
            <tr style={{ background: "#1a2340" }}>
              <th style={{ padding: "8px 12px", textAlign: "left", color: "white", fontSize: 12 }}>Descrição</th>
              <th style={{ padding: "8px 12px", textAlign: "right", color: "white", fontSize: 12 }}>Por Unidade</th>
              <th style={{ padding: "8px 12px", textAlign: "right", color: "white", fontSize: 12 }}>Total</th>
            </tr>
          </thead>
          <tbody>
            {row("Valor de Venda", fmt(study.valor_venda_unidade), true)}
            {row("(-) Terreno", fmt(study.custo_terreno_unidade))}
            {row("(-) Impostos e Taxas", fmt(study.custo_impostos_unidade))}
            {row("(-) Comercialização", fmt(study.custo_comercializacao_unidade))}
            {row("(-) Engenharia", fmt(study.custo_engenharia_unidade))}
            <tr style={{ background: "#1a2340" }}>
              <td style={{ padding: "8px 12px", color: "#C9A96E", fontWeight: 700, fontSize: 12 }}>= Resultado</td>
              <td style={{ padding: "8px 12px", textAlign: "right", color: "#C9A96E", fontWeight: 700, fontSize: 12 }}>{fmt(study.resultado_unidade)}</td>
              <td style={{ padding: "8px 12px", textAlign: "right", color: "#C9A96E", fontWeight: 700, fontSize: 12 }}>{fmt(study.resultado_total)}</td>
            </tr>
          </tbody>
        </table>
      </div>

      {/* Sensitivity */}
      <div style={{ marginBottom: 24 }}>
        <div style={{ fontSize: 13, fontWeight: 700, color: "#1a2340", marginBottom: 8, textTransform: "uppercase", letterSpacing: 1 }}>Análise de Cenários</div>
        <table style={{ width: "100%", borderCollapse: "collapse", border: "1px solid #eee" }}>
          <thead>
            <tr style={{ background: "#f5f5f5" }}>
              <th style={{ padding: "8px 12px", textAlign: "left", fontSize: 12, color: "#555" }}>Cenário</th>
              <th style={{ padding: "8px 12px", textAlign: "right", fontSize: 12, color: "#555" }}>Variação Custo</th>
              <th style={{ padding: "8px 12px", textAlign: "right", fontSize: 12, color: "#555" }}>Variação Receita</th>
              <th style={{ padding: "8px 12px", textAlign: "right", fontSize: 12, color: "#555" }}>Lucro</th>
              <th style={{ padding: "8px 12px", textAlign: "right", fontSize: 12, color: "#555" }}>Margem</th>
            </tr>
          </thead>
          <tbody>
            {[
              { name: "Pessimista", cv: 0.15, rv: -0.10 },
              { name: "Realista", cv: 0, rv: 0 },
              { name: "Otimista", cv: -0.05, rv: 0.10 },
            ].map((s, i) => {
              const vgvS = (study.vgv_total || 0) * (1 + s.rv);
              const custoS = custoTotal * (1 + s.cv);
              const lucroS = vgvS - custoS;
              const margemS = vgvS > 0 ? lucroS / vgvS : 0;
              return (
                <tr key={i} style={{ background: i % 2 === 0 ? "white" : "#fafafa" }}>
                  <td style={{ padding: "8px 12px", fontWeight: 600, fontSize: 12 }}>{s.name}</td>
                  <td style={{ padding: "8px 12px", textAlign: "right", fontSize: 12, color: s.cv > 0 ? "#b00020" : s.cv < 0 ? "#1a6b40" : "#555" }}>{s.cv > 0 ? '+' : ''}{(s.cv * 100).toFixed(0)}%</td>
                  <td style={{ padding: "8px 12px", textAlign: "right", fontSize: 12, color: s.rv > 0 ? "#1a6b40" : s.rv < 0 ? "#b00020" : "#555" }}>{s.rv > 0 ? '+' : ''}{(s.rv * 100).toFixed(0)}%</td>
                  <td style={{ padding: "8px 12px", textAlign: "right", fontSize: 12, fontWeight: 700, color: lucroS > 0 ? "#1a6b40" : "#b00020" }}>{fmt(lucroS)}</td>
                  <td style={{ padding: "8px 12px", textAlign: "right", fontSize: 12, fontWeight: 700, color: margemS > 0.10 ? "#1a6b40" : "#b00020" }}>{fmtPerc(margemS)}</td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {/* Footer */}
      <div style={{ borderTop: "1px solid #eee", paddingTop: 12, display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <span style={{ fontSize: 10, color: "#bbb" }}>Ponto de equilíbrio: {breakEvenUnits} unidades vendidas ({study.num_unidades > 0 ? ((breakEvenUnits / study.num_unidades) * 100).toFixed(0) : 0}% das unidades)</span>
        <span style={{ fontSize: 10, color: "#bbb" }}>Taxa de desconto: {fmtPerc(taxaAnual)} a.a.</span>
      </div>
    </div>
  );
}

export default function PDFReport({ study }) {
  const reportRef = useRef(null);
  const [generating, setGenerating] = useState(false);
  const [showTemplate, setShowTemplate] = useState(false);

  async function handleExport() {
    setGenerating(true);
    setShowTemplate(true);
    await new Promise((r) => setTimeout(r, 300));
    try {
      const canvas = await html2canvas(reportRef.current, { scale: 2, useCORS: true, backgroundColor: "#ffffff" });
      const imgData = canvas.toDataURL("image/png");
      const pdf = new jsPDF({ orientation: "portrait", unit: "mm", format: "a4" });
      const pdfWidth = pdf.internal.pageSize.getWidth();
      const pdfHeight = (canvas.height * pdfWidth) / canvas.width;
      pdf.addImage(imgData, "PNG", 0, 0, pdfWidth, pdfHeight);
      pdf.save(`Viabilidade_${study.nome_empreendimento?.replace(/\s+/g, "_") || "estudo"}.pdf`);
    } finally {
      setShowTemplate(false);
      setGenerating(false);
    }
  }

  return (
    <>
      <Button
        onClick={handleExport}
        disabled={generating}
        variant="outline"
        className="border-white/10 text-white/60 hover:text-white hover:border-white/30 hover:bg-white/5"
      >
        {generating ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <FileDown className="w-4 h-4 mr-2" />}
        Exportar PDF
      </Button>
      {showTemplate && (
        <div style={{ position: "fixed", left: -9999, top: 0, zIndex: -1 }}>
          <ReportTemplate study={study} reportRef={reportRef} />
        </div>
      )}
    </>
  );
}